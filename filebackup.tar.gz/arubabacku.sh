#!/bin/bash

tar cvf backup_$(date +"%m_%d_%Y").gz /root/arubabackup/
sftp root@67.225.240.21:/home/arubaremotebackup <<<$'put backup_'$(date +"%m_%d_%Y")'.gz'
rm -r backup_$(date +"%m_%d_%Y").gz
